package com.example.kashapp.Prevalent;

import com.example.kashapp.Model.Users;

public class Prevalent {

    private static Users CurrentOnlineUsers;
}
